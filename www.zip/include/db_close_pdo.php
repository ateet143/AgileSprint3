<?php
unset($pdo);
?>